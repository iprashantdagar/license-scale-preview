# LS Landing — GHL Template

Ready-to-import hybrid template for **License & Scale — Start an AI agency. Scale it to seven figures.**.

## Import (~10 min)

1. GHL → Sites / Funnels → New page → **`LS Landing`**
2. Page background: `#0B0A12`
3. Tracking → **Header** → `00-HEAD-tracking.html`
4. Tracking → **Footer** → `99-FOOTER-tracking.html`, then `99b-FOOTER-page-scripts.html`
5. One full-width **Custom Code** → `03-FULL-BODY-one-block.html`
6. Save → preview → hard refresh

## After all 5 pages exist
Fill `window.LS_PAGE_URLS` in Header tracking on every page.

## Contents
- `sections/` — per-section pastes
- `native/EDITABLE-MAP.md` — native vs Custom Code
- `native/COPY-SHEET.md` — copy for native rebuild

## Form
See `../FORMS/` — swap needed (`typeform-survey`).
